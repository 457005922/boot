CREATE VIEW pro_product_view AS
  SELECT
    `pbv`.`id`                                   AS `id`,
    `pbv`.`createTime`                           AS `createTime`,
    `pbv`.`deleteStatus`                         AS `deleteStatus`,
    `pbv`.`updateTime`                           AS `updateTime`,
    `pbv`.`barcode`                              AS `barcode`,
    `pbv`.`brand`                                AS `brand`,
    `pbv`.`expirationDays`                       AS `expirationDays`,
    `pbv`.`name`                                 AS `name`,
    `pbv`.`no`                                   AS `no`,
    (CASE WHEN (isnull(`pp`.`picUrl`) OR (`pp`.`picUrl` = ''))
      THEN `pbv`.`picUrl`
     ELSE `pp`.`picUrl` END)                     AS `picUrl`,
    `pbv`.`pkg`                                  AS `pkg`,
    `pbv`.`pkgId`                                AS `pkgId`,
    `pbv`.`spec`                                 AS `spec`,
    `pbv`.`syncId`                               AS `syncId`,
    `pbv`.`type`                                 AS `type`,
    `pbv`.`categoryId`                           AS `categoryId`,
    `pbv`.`categoryName`                         AS `categoryName`,
    `pbv`.`firstCategoryId`                      AS `firstCategoryId`,
    `pbv`.`firstCategoryName`                    AS `firstCategoryName`,
    `pbv`.`customId`                             AS `customId`,
    `pp`.`storeId`                               AS `storeId`,
    `pp`.`id`                                    AS `productId`,
    `pp`.`purchasePrice`                         AS `purchasePrice`,
    `pp`.`sellingPrice`                          AS `sellingPrice`,
    `pp`.`statusDate`                            AS `statusDate`,
    (`pp`.`sellingPrice` - `pp`.`purchasePrice`) AS `profit`,
    `pp`.`inventory`                             AS `inventory`,
    `pp`.`status`                                AS `productStatus`,
    `pp`.`safetyInventoryDays`                   AS `safetyInventoryDays`
  FROM (`pos`.`pro_base_view` `pbv`
    JOIN `pos`.`pro_product` `pp` ON ((`pp`.`baseId` = `pbv`.`id`)));

