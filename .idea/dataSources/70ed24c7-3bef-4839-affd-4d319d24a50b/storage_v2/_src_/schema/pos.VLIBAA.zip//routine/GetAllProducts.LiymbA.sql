CREATE PROCEDURE GetAllProducts()
  BEGIN
			SELECT * FROM ord_order_info;
END;

