CREATE VIEW pro_base_view AS
  SELECT
    `ba`.`id`             AS `id`,
    `ba`.`createTime`     AS `createTime`,
    `ba`.`deleteStatus`   AS `deleteStatus`,
    `ba`.`updateTime`     AS `updateTime`,
    `ba`.`barcode`        AS `barcode`,
    `ba`.`brand`          AS `brand`,
    `ba`.`expirationDays` AS `expirationDays`,
    `ba`.`name`           AS `name`,
    `ba`.`no`             AS `no`,
    `ba`.`picUrl`         AS `picUrl`,
    `ba`.`pkg`            AS `pkg`,
    `ba`.`pkgId`          AS `pkgId`,
    `ba`.`spec`           AS `spec`,
    `ba`.`syncId`         AS `syncId`,
    `ba`.`type`           AS `type`,
    `ba`.`categoryId`     AS `categoryId`,
    `ba`.`customId`       AS `customId`,
    `pc2`.`name`          AS `categoryName`,
    `pc2`.`parentId`      AS `firstCategoryId`,
    `pc1`.`name`          AS `firstCategoryName`
  FROM ((`pos`.`pro_base` `ba`
    JOIN `pos`.`pro_category` `pc2` ON ((`pc2`.`id` = `ba`.`categoryId`))) JOIN `pos`.`pro_category` `pc1`
      ON ((`pc1`.`id` = `pc2`.`parentId`)))
  WHERE (`ba`.`deleteStatus` = 0);

