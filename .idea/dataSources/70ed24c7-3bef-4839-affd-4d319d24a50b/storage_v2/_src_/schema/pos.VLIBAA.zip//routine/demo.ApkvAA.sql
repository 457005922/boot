CREATE PROCEDURE demo()
  BEGIN
		 DECLARE USER_DONE INT DEFAULT 0;
DECLARE USER_ID VARCHAR(32); #用户ID
		 DECLARE USER_RS CURSOR FOR SELECT us.id FROM `acc_admin` us WHERE us.deleteStatus=0;
		 DECLARE CONTINUE HANDLER FOR NOT FOUND SET USER_DONE = 1;
		 
  OPEN USER_RS;
    /* 遍历数据表 */
    REPEAT
      /* 逐个取出当前记录,进行初始化逻辑 */
      FETCH USER_RS INTO USER_ID;
      IF NOT USER_DONE THEN
        IF USER_ID IS NOT NULL AND USER_ID!='' THEN
          # 暂时关闭外键检查
          SET FOREIGN_KEY_CHECKS=0;
          INSERT INTO `acc_admin_permission`(`adminId`,`permissionId`) SELECT 'PLACE_HOLDER',ap.`id` FROM acc_permission ap
          WHERE ap.deleteStatus=0 AND ap.status=1 AND ap.`id` NOT IN(SELECT aap.permissionId FROM acc_admin_permission aap WHERE aap.adminId=USER_ID);
          #把PLACE_HOLDER点位符替换为当前用户ID
          UPDATE `acc_admin_permission` SET adminId=USER_ID WHERE adminId='PLACE_HOLDER';
          # 恢复外键检查
          SET FOREIGN_KEY_CHECKS=1;
        END IF;
      END IF;
    UNTIL USER_DONE END REPEAT;
    CLOSE USER_RS;
	END;

