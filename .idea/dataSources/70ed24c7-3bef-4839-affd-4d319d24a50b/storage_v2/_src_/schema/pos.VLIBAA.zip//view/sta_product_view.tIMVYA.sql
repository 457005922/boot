CREATE VIEW sta_product_view AS
  SELECT
    `ood`.`id`           AS `id`,
    `ooi`.`storeId`      AS `storeId`,
    `ood`.`productId`    AS `productId`,
    `ood`.`name`         AS `name`,
    `ood`.`barcode`      AS `barcode`,
    `ood`.`price`        AS `price`,
    `pc1`.`id`           AS `firstCategoryId`,
    `pc1`.`name`         AS `firstCategoryName`,
    `pc2`.`id`           AS `secondCategoryId`,
    `pc2`.`name`         AS `secondCategoryName`,
    `ood`.`quantity`     AS `quantity`,
    `ood`.`totalPrice`   AS `amount`,
    `ood`.`cost`         AS `cost`,
    `ood`.`profit`       AS `profit`,
    `ood`.`createTime`   AS `createTime`,
    `ood`.`updateTime`   AS `updateTime`,
    `ood`.`deleteStatus` AS `deleteStatus`,
    `ss`.`storeType`     AS `storeType`,
    `pp`.`purchasePrice` AS `purchasePrice`,
    `pp`.`inventory`     AS `inventory`,
    `pb`.`pkg`           AS `pkg`,
    `pp`.`statusDate`    AS `statusDate`,
    `pb`.`customId`      AS `customId`
  FROM ((((((`pos`.`ord_order_detail` `ood`
    JOIN `pos`.`ord_order_info` `ooi` ON ((`ooi`.`id` = `ood`.`orderInfoId`))) JOIN `pos`.`pro_product` `pp`
      ON ((`pp`.`id` = `ood`.`productId`))) JOIN `pos`.`pro_base` `pb` ON ((`pb`.`id` = `pp`.`baseId`))) JOIN
    `pos`.`pro_category` `pc2` ON ((`pc2`.`id` = `pb`.`categoryId`))) JOIN `pos`.`pro_category` `pc1`
      ON ((`pc1`.`id` = `pc2`.`parentId`))) JOIN `pos`.`sys_store` `ss` ON ((`ss`.`id` = `ooi`.`storeId`)))
  WHERE
    ((`ood`.`deleteStatus` = 0) AND (`ooi`.`deleteStatus` = 0) AND (`ooi`.`status` = 1) AND (`ooi`.`payStatus` = 1) AND
     (`ooi`.`tradeType` = 1));

