CREATE VIEW sta_refund_view AS
  SELECT
    `ooi`.`id`              AS `id`,
    `ooi`.`createTime`      AS `createTime`,
    `ooi`.`deleteStatus`    AS `deleteStatus`,
    `ooi`.`updateTime`      AS `updateTime`,
    `ooi`.`actualPayAmount` AS `actualPayAmount`,
    `ooi`.`cost`            AS `cost`,
    `ooi`.`createBy`        AS `createBy`,
    `ooi`.`discountDesc`    AS `discountDesc`,
    `ooi`.`goodsAmount`     AS `goodsAmount`,
    `ooi`.`orderAmount`     AS `orderAmount`,
    `ooi`.`orderNo`         AS `orderNo`,
    `ooi`.`pOrderNo`        AS `pOrderNo`,
    `ooi`.`payReturnMsg`    AS `payReturnMsg`,
    `ooi`.`payStatus`       AS `payStatus`,
    `ooi`.`payTypeCode`     AS `payTypeCode`,
    `ooi`.`payTypeName`     AS `payTypeName`,
    `ooi`.`profit`          AS `profit`,
    `ooi`.`quantity`        AS `quantity`,
    `ooi`.`rebateAmount`    AS `rebateAmount`,
    `ooi`.`refundAmount`    AS `refundAmount`,
    `ooi`.`remark`          AS `remark`,
    `ooi`.`status`          AS `status`,
    `ooi`.`storeId`         AS `storeId`,
    `ooi`.`storeName`       AS `storeName`,
    `ooi`.`tradeNo`         AS `tradeNo`,
    `ooi`.`tradeType`       AS `tradeType`,
    `ooi`.`updateBy`        AS `updateBy`,
    `ooi`.`updateByName`    AS `cashier`,
    `ss`.`storeType`        AS `storeType`
  FROM (`pos`.`ord_order_info` `ooi`
    JOIN `pos`.`sys_store` `ss` ON ((`ss`.`id` = `ooi`.`storeId`)))
  WHERE ((`ooi`.`tradeType` = 2) AND (`ooi`.`status` = 1));

