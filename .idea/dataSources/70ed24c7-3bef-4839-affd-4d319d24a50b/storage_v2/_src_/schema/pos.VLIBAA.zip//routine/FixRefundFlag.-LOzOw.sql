CREATE PROCEDURE FixRefundFlag()
  BEGIN
    #修正订单表中表示是否有退款的标记
    DECLARE ORDER_DONE INT DEFAULT 0;
    DECLARE PARENT_ORDER_NO VARCHAR(32); #父订单ID
    /* 声明游标 */
    /*取出订单编号*/
    DECLARE ORDER_RS CURSOR FOR SELECT ooi.pOrderNo
        FROM `ord_order_info` ooi
        WHERE ooi.tradeType=2 AND ooi.payStatus=1 AND ooi.status=1 AND ooi.deleteStatus=0;
    /* 异常处理 */
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET ORDER_DONE = 1;
    /* 打开游标 */
    OPEN ORDER_RS;
    /* 遍历数据表 */
    REPEAT
      /* 逐个取出当前记录,进行初始化逻辑 */
      FETCH ORDER_RS INTO PARENT_ORDER_NO;
      IF NOT ORDER_DONE THEN
        IF PARENT_ORDER_NO IS NOT NULL AND PARENT_ORDER_NO!='' THEN
          UPDATE ord_order_info SET `refund` = 2 WHERE orderNo=PARENT_ORDER_NO;
        END IF;
      END IF;
    UNTIL ORDER_DONE
    END REPEAT;
    CLOSE ORDER_RS;
  END;

