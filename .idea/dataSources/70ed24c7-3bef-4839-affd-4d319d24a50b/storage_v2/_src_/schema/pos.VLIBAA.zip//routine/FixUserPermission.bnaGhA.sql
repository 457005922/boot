CREATE PROCEDURE FixUserPermission()
  BEGIN
    #修正收银用户的非检查权限
    DECLARE USER_DONE INT DEFAULT 0;
    DECLARE USER_ID VARCHAR(32); #用户ID
    DECLARE IS_ADMIN SMALLINT(3); #是否是管理员
    /* 声明游标 */
    /*取出所有用户的ID及其是否是管理员的标记*/
    DECLARE USER_RS CURSOR FOR SELECT us.id,us.isAdmin FROM `acc_user` us WHERE us.deleteStatus=0;
    /* 异常处理 */
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET USER_DONE = 1;
    /* 打开游标 */
    OPEN USER_RS;
    /* 遍历数据表 */
    REPEAT
      /* 逐个取出当前记录,进行初始化逻辑 */
      FETCH USER_RS INTO USER_ID,IS_ADMIN;
      IF NOT USER_DONE THEN
        IF USER_ID IS NOT NULL AND USER_ID!='' AND IS_ADMIN IS NOT NULL THEN
          # 暂时关闭外键检查
          SET FOREIGN_KEY_CHECKS=0;
          IF IS_ADMIN=1 THEN
            # 如果是管理员，则赋予所有权限
            INSERT INTO `acc_user_resource`(`userId`,`resourceId`) SELECT 'PLACE_HOLDER',ar.`id` FROM acc_resource ar
            WHERE ar.deleteStatus=0 AND ar.status=1 AND ar.`id` NOT IN(SELECT aur.resourceId FROM acc_user_resource aur WHERE aur.userId=USER_ID);
          ELSE
            # 如果不是管理员，则赋予所有非检查性权限
            INSERT INTO `acc_user_resource`(`userId`,`resourceId`) SELECT 'PLACE_HOLDER',ar.`id` FROM acc_resource ar
            WHERE ar.deleteStatus=0 AND ar.status=1 AND ar.needCheck=0 AND ar.`id` NOT IN(SELECT aur.resourceId FROM acc_user_resource aur WHERE aur.userId=USER_ID);
          END IF ;
          #把PLACE_HOLDER点位符替换为当前用户ID
          UPDATE `acc_user_resource` SET userId=USER_ID WHERE userId='PLACE_HOLDER';
          # 恢复外键检查
          SET FOREIGN_KEY_CHECKS=1;
        END IF;
      END IF;
    UNTIL USER_DONE END REPEAT;
    CLOSE USER_RS;
  END;

